package com.example.lab1dipanshu;

public class employees {

    private int ID;
    private String Employeename;
    private int Workinghours;
    private String Companyname;

    public employees(int ID, String Employeename, int Workinghours, String Companyname) {
        this.ID = ID;
        this.Employeename = Employeename;
        this.Workinghours = Workinghours;
        this.Companyname = Companyname;
    }
    public int getID() {
        return ID;
    }
    public String getEmployeename() {
        return Employeename;
    }
    public int getWorkinghours() {
        return Workinghours;
    }
    public String getCompanyname() {
        return Companyname;
    }
}

