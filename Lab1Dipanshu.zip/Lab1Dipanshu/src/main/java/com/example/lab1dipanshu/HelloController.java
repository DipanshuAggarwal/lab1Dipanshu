package com.example.lab1dipanshu;


import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import java.net.URL;
import java.util.ResourceBundle;
import java.sql.*;
public class HelloController implements Initializable {
    @FXML
    private TableView<employees> tableView;
    @FXML
    private TableColumn<employees,Integer > ID;
    @FXML
    private TableColumn<employees, String> Employeename;
    @FXML
    private TableColumn<employees,Integer> Workinghours;
    @FXML
    private TableColumn<employees,String> Companyname;
    ObservableList<employees> list = FXCollections.observableArrayList();
    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        ID.setCellValueFactory(new
                PropertyValueFactory<employees,Integer>("ID"));
        Employeename.setCellValueFactory(new
                PropertyValueFactory<employees,String>("Employeename"));
        Workinghours.setCellValueFactory(new
                PropertyValueFactory<employees,Integer>("Workinghours"));
        Companyname.setCellValueFactory(new
                PropertyValueFactory<employees,String>("Companyname"));
        tableView.setItems(list);
    }
    @FXML
    protected void onHelloButtonClick() {
        populateTable();
    }
    public void populateTable() {
        // Establish a database connection
        String jdbcUrl = "jdbc:mysql://localhost:3306/db_lab1";
        String dbUser = "root";
        String dbPassword = "";
        try (Connection connection = DriverManager.getConnection(jdbcUrl, dbUser,
                dbPassword)) {
            // Execute a SQL query to retrieve data from the database
            String query = "SELECT * FROM employees";
            Statement statement = connection.createStatement();
            ResultSet resultSet = statement.executeQuery(query);
            // Populate the table with data from the database
            while (resultSet.next()) {
                int ID = resultSet.getInt("ID");
                String Employeename = resultSet.getString("Employeename");
                int Workinghours = resultSet.getInt("Workinghours");
                String Companyname = resultSet.getString("Companyname");
                tableView.getItems().add(new employees(ID, Employeename, Workinghours, Companyname));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
    }
