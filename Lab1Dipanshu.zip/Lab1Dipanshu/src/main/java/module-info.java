module com.example.lab1dipanshu {
    requires javafx.controls;
    requires javafx.fxml;
    requires java.sql;


    opens com.example.lab1dipanshu to javafx.fxml;
    exports com.example.lab1dipanshu;
}